

public enum TrashType {
    HoleySocks,
    BananaPeels,
    BiohazardVials,
    PlasticBottles,
    BrokenToys;
}
